Referencia: 

Kim, J. (2022, 25 mayo). Stacks in Go. DEV Community. https://dev.to/jpoly1219/stacks-in-go-54k

Liga de git: 

https://github.com/A00832309/Proyecto